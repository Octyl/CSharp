﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Hello world!!! - writeln");

            Console.Write("Hello ");
            Console.Write("world ");
            Console.Write("!!! - write");


            Console.ReadKey();
        }
    }
}
